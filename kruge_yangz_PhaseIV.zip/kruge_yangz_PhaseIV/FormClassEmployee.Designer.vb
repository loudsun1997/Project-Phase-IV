﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormClassEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnInfoNew = New System.Windows.Forms.Button()
        Me.btnInfoSave = New System.Windows.Forms.Button()
        Me.btnInfoDelete = New System.Windows.Forms.Button()
        Me.btnExpNew = New System.Windows.Forms.Button()
        Me.btnExpSave = New System.Windows.Forms.Button()
        Me.btnExpDelete = New System.Windows.Forms.Button()
        Me.btnQualNew = New System.Windows.Forms.Button()
        Me.btnQualSave = New System.Windows.Forms.Button()
        Me.btnQualDelete = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.btnAll = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtHrsPerWk = New System.Windows.Forms.TextBox()
        Me.txtSalaryScale = New System.Windows.Forms.TextBox()
        Me.txtPayType = New System.Windows.Forms.TextBox()
        Me.txtPosPermTemp = New System.Windows.Forms.TextBox()
        Me.txtCurrSalary = New System.Windows.Forms.TextBox()
        Me.txtEmpPosition = New System.Windows.Forms.TextBox()
        Me.txtStaffNo = New System.Windows.Forms.TextBox()
        Me.txtFName = New System.Windows.Forms.TextBox()
        Me.txtLName = New System.Windows.Forms.TextBox()
        Me.txtStreet = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.txtZip = New System.Windows.Forms.TextBox()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.txtGender = New System.Windows.Forms.TextBox()
        Me.txtNin = New System.Windows.Forms.TextBox()
        Me.boxValue = New System.Windows.Forms.TextBox()
        Me.txtWorkPosition = New System.Windows.Forms.TextBox()
        Me.txtOrgName = New System.Windows.Forms.TextBox()
        Me.txtQualType = New System.Windows.Forms.TextBox()
        Me.txtInstName = New System.Windows.Forms.TextBox()
        Me.DatePickerDOB = New System.Windows.Forms.DateTimePicker()
        Me.DatePickerStartDate = New System.Windows.Forms.DateTimePicker()
        Me.DatePickerFinishDate = New System.Windows.Forms.DateTimePicker()
        Me.DatePickerQual = New System.Windows.Forms.DateTimePicker()
        Me.boxField = New System.Windows.Forms.ComboBox()
        Me.btnExpFirst = New System.Windows.Forms.Button()
        Me.btnExpPrev = New System.Windows.Forms.Button()
        Me.btnExpNext = New System.Windows.Forms.Button()
        Me.btnExpLast = New System.Windows.Forms.Button()
        Me.txtBoxExpPg = New System.Windows.Forms.TextBox()
        Me.txtBoxQualPg = New System.Windows.Forms.TextBox()
        Me.btnQualFirst = New System.Windows.Forms.Button()
        Me.btnQualPrev = New System.Windows.Forms.Button()
        Me.btnQualNext = New System.Windows.Forms.Button()
        Me.btnQualLast = New System.Windows.Forms.Button()
        Me.txtEmpPageNum = New System.Windows.Forms.TextBox()
        Me.btnInfoPrev = New System.Windows.Forms.Button()
        Me.btnInfoFirst = New System.Windows.Forms.Button()
        Me.btnInfoNext = New System.Windows.Forms.Button()
        Me.btnInfoLast = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnInfoNew
        '
        Me.btnInfoNew.Location = New System.Drawing.Point(21, 553)
        Me.btnInfoNew.Name = "btnInfoNew"
        Me.btnInfoNew.Size = New System.Drawing.Size(75, 23)
        Me.btnInfoNew.TabIndex = 0
        Me.btnInfoNew.Text = "New"
        Me.btnInfoNew.UseVisualStyleBackColor = True
        '
        'btnInfoSave
        '
        Me.btnInfoSave.Location = New System.Drawing.Point(102, 553)
        Me.btnInfoSave.Name = "btnInfoSave"
        Me.btnInfoSave.Size = New System.Drawing.Size(75, 23)
        Me.btnInfoSave.TabIndex = 1
        Me.btnInfoSave.Text = "Save"
        Me.btnInfoSave.UseVisualStyleBackColor = True
        '
        'btnInfoDelete
        '
        Me.btnInfoDelete.Location = New System.Drawing.Point(189, 553)
        Me.btnInfoDelete.Name = "btnInfoDelete"
        Me.btnInfoDelete.Size = New System.Drawing.Size(75, 23)
        Me.btnInfoDelete.TabIndex = 2
        Me.btnInfoDelete.Text = "Delete"
        Me.btnInfoDelete.UseVisualStyleBackColor = True
        '
        'btnExpNew
        '
        Me.btnExpNew.Location = New System.Drawing.Point(420, 370)
        Me.btnExpNew.Name = "btnExpNew"
        Me.btnExpNew.Size = New System.Drawing.Size(75, 23)
        Me.btnExpNew.TabIndex = 3
        Me.btnExpNew.Text = "New"
        Me.btnExpNew.UseVisualStyleBackColor = True
        '
        'btnExpSave
        '
        Me.btnExpSave.Location = New System.Drawing.Point(520, 370)
        Me.btnExpSave.Name = "btnExpSave"
        Me.btnExpSave.Size = New System.Drawing.Size(75, 23)
        Me.btnExpSave.TabIndex = 4
        Me.btnExpSave.Text = "Save"
        Me.btnExpSave.UseVisualStyleBackColor = True
        '
        'btnExpDelete
        '
        Me.btnExpDelete.Location = New System.Drawing.Point(613, 370)
        Me.btnExpDelete.Name = "btnExpDelete"
        Me.btnExpDelete.Size = New System.Drawing.Size(75, 23)
        Me.btnExpDelete.TabIndex = 5
        Me.btnExpDelete.Text = "Delete"
        Me.btnExpDelete.UseVisualStyleBackColor = True
        '
        'btnQualNew
        '
        Me.btnQualNew.Location = New System.Drawing.Point(435, 154)
        Me.btnQualNew.Name = "btnQualNew"
        Me.btnQualNew.Size = New System.Drawing.Size(75, 23)
        Me.btnQualNew.TabIndex = 6
        Me.btnQualNew.Text = "New"
        Me.btnQualNew.UseVisualStyleBackColor = True
        '
        'btnQualSave
        '
        Me.btnQualSave.Location = New System.Drawing.Point(516, 154)
        Me.btnQualSave.Name = "btnQualSave"
        Me.btnQualSave.Size = New System.Drawing.Size(75, 23)
        Me.btnQualSave.TabIndex = 7
        Me.btnQualSave.Text = "Save"
        Me.btnQualSave.UseVisualStyleBackColor = True
        '
        'btnQualDelete
        '
        Me.btnQualDelete.Location = New System.Drawing.Point(597, 154)
        Me.btnQualDelete.Name = "btnQualDelete"
        Me.btnQualDelete.Size = New System.Drawing.Size(75, 23)
        Me.btnQualDelete.TabIndex = 8
        Me.btnQualDelete.Text = "Delete"
        Me.btnQualDelete.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(639, 488)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(75, 23)
        Me.btnSearch.TabIndex = 9
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'btnAll
        '
        Me.btnAll.Location = New System.Drawing.Point(639, 449)
        Me.btnAll.Name = "btnAll"
        Me.btnAll.Size = New System.Drawing.Size(75, 23)
        Me.btnAll.TabIndex = 10
        Me.btnAll.Text = "All"
        Me.btnAll.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(369, 553)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtHrsPerWk
        '
        Me.txtHrsPerWk.Location = New System.Drawing.Point(102, 440)
        Me.txtHrsPerWk.Name = "txtHrsPerWk"
        Me.txtHrsPerWk.Size = New System.Drawing.Size(216, 20)
        Me.txtHrsPerWk.TabIndex = 12
        '
        'txtSalaryScale
        '
        Me.txtSalaryScale.Location = New System.Drawing.Point(102, 414)
        Me.txtSalaryScale.Name = "txtSalaryScale"
        Me.txtSalaryScale.Size = New System.Drawing.Size(216, 20)
        Me.txtSalaryScale.TabIndex = 13
        '
        'txtPayType
        '
        Me.txtPayType.Location = New System.Drawing.Point(102, 490)
        Me.txtPayType.Name = "txtPayType"
        Me.txtPayType.Size = New System.Drawing.Size(216, 20)
        Me.txtPayType.TabIndex = 14
        '
        'txtPosPermTemp
        '
        Me.txtPosPermTemp.Location = New System.Drawing.Point(102, 466)
        Me.txtPosPermTemp.Name = "txtPosPermTemp"
        Me.txtPosPermTemp.Size = New System.Drawing.Size(216, 20)
        Me.txtPosPermTemp.TabIndex = 15
        '
        'txtCurrSalary
        '
        Me.txtCurrSalary.Location = New System.Drawing.Point(102, 388)
        Me.txtCurrSalary.Name = "txtCurrSalary"
        Me.txtCurrSalary.Size = New System.Drawing.Size(216, 20)
        Me.txtCurrSalary.TabIndex = 16
        '
        'txtEmpPosition
        '
        Me.txtEmpPosition.Location = New System.Drawing.Point(102, 363)
        Me.txtEmpPosition.Name = "txtEmpPosition"
        Me.txtEmpPosition.Size = New System.Drawing.Size(216, 20)
        Me.txtEmpPosition.TabIndex = 17
        '
        'txtStaffNo
        '
        Me.txtStaffNo.Location = New System.Drawing.Point(102, 64)
        Me.txtStaffNo.Name = "txtStaffNo"
        Me.txtStaffNo.Size = New System.Drawing.Size(216, 20)
        Me.txtStaffNo.TabIndex = 18
        '
        'txtFName
        '
        Me.txtFName.Location = New System.Drawing.Point(102, 94)
        Me.txtFName.Name = "txtFName"
        Me.txtFName.Size = New System.Drawing.Size(216, 20)
        Me.txtFName.TabIndex = 19
        '
        'txtLName
        '
        Me.txtLName.Location = New System.Drawing.Point(102, 117)
        Me.txtLName.Name = "txtLName"
        Me.txtLName.Size = New System.Drawing.Size(216, 20)
        Me.txtLName.TabIndex = 20
        '
        'txtStreet
        '
        Me.txtStreet.Location = New System.Drawing.Point(102, 143)
        Me.txtStreet.Name = "txtStreet"
        Me.txtStreet.Size = New System.Drawing.Size(216, 20)
        Me.txtStreet.TabIndex = 21
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(102, 169)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(216, 20)
        Me.txtCity.TabIndex = 22
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(102, 198)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(216, 20)
        Me.txtState.TabIndex = 23
        '
        'txtZip
        '
        Me.txtZip.Location = New System.Drawing.Point(102, 224)
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(216, 20)
        Me.txtZip.TabIndex = 24
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(102, 250)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(216, 20)
        Me.txtPhone.TabIndex = 25
        '
        'txtGender
        '
        Me.txtGender.Location = New System.Drawing.Point(102, 307)
        Me.txtGender.Name = "txtGender"
        Me.txtGender.Size = New System.Drawing.Size(216, 20)
        Me.txtGender.TabIndex = 26
        '
        'txtNin
        '
        Me.txtNin.Location = New System.Drawing.Point(102, 334)
        Me.txtNin.Name = "txtNin"
        Me.txtNin.Size = New System.Drawing.Size(216, 20)
        Me.txtNin.TabIndex = 27
        '
        'boxValue
        '
        Me.boxValue.Location = New System.Drawing.Point(483, 488)
        Me.boxValue.Name = "boxValue"
        Me.boxValue.Size = New System.Drawing.Size(122, 20)
        Me.boxValue.TabIndex = 28
        '
        'txtWorkPosition
        '
        Me.txtWorkPosition.Location = New System.Drawing.Point(472, 259)
        Me.txtWorkPosition.Name = "txtWorkPosition"
        Me.txtWorkPosition.Size = New System.Drawing.Size(200, 20)
        Me.txtWorkPosition.TabIndex = 29
        '
        'txtOrgName
        '
        Me.txtOrgName.Location = New System.Drawing.Point(472, 221)
        Me.txtOrgName.Name = "txtOrgName"
        Me.txtOrgName.Size = New System.Drawing.Size(200, 20)
        Me.txtOrgName.TabIndex = 30
        '
        'txtQualType
        '
        Me.txtQualType.Location = New System.Drawing.Point(472, 55)
        Me.txtQualType.Name = "txtQualType"
        Me.txtQualType.Size = New System.Drawing.Size(200, 20)
        Me.txtQualType.TabIndex = 31
        '
        'txtInstName
        '
        Me.txtInstName.Location = New System.Drawing.Point(472, 91)
        Me.txtInstName.Name = "txtInstName"
        Me.txtInstName.Size = New System.Drawing.Size(200, 20)
        Me.txtInstName.TabIndex = 32
        '
        'DatePickerDOB
        '
        Me.DatePickerDOB.CustomFormat = "mm/dd/yyyy"
        Me.DatePickerDOB.Location = New System.Drawing.Point(102, 278)
        Me.DatePickerDOB.Name = "DatePickerDOB"
        Me.DatePickerDOB.Size = New System.Drawing.Size(216, 20)
        Me.DatePickerDOB.TabIndex = 33
        '
        'DatePickerStartDate
        '
        Me.DatePickerStartDate.CustomFormat = "mm/dd/yyyy"
        Me.DatePickerStartDate.Location = New System.Drawing.Point(472, 289)
        Me.DatePickerStartDate.Name = "DatePickerStartDate"
        Me.DatePickerStartDate.Size = New System.Drawing.Size(200, 20)
        Me.DatePickerStartDate.TabIndex = 34
        '
        'DatePickerFinishDate
        '
        Me.DatePickerFinishDate.CustomFormat = "mm/dd/yyyy"
        Me.DatePickerFinishDate.Location = New System.Drawing.Point(472, 312)
        Me.DatePickerFinishDate.Name = "DatePickerFinishDate"
        Me.DatePickerFinishDate.Size = New System.Drawing.Size(200, 20)
        Me.DatePickerFinishDate.TabIndex = 35
        '
        'DatePickerQual
        '
        Me.DatePickerQual.CustomFormat = "mm/dd/yyyy"
        Me.DatePickerQual.Location = New System.Drawing.Point(472, 29)
        Me.DatePickerQual.Name = "DatePickerQual"
        Me.DatePickerQual.Size = New System.Drawing.Size(200, 20)
        Me.DatePickerQual.TabIndex = 36
        '
        'boxField
        '
        Me.boxField.FormattingEnabled = True
        Me.boxField.Items.AddRange(New Object() {"TYPE", "ORGNAME"})
        Me.boxField.Location = New System.Drawing.Point(483, 449)
        Me.boxField.Name = "boxField"
        Me.boxField.Size = New System.Drawing.Size(121, 21)
        Me.boxField.TabIndex = 37
        '
        'btnExpFirst
        '
        Me.btnExpFirst.Location = New System.Drawing.Point(420, 338)
        Me.btnExpFirst.Name = "btnExpFirst"
        Me.btnExpFirst.Size = New System.Drawing.Size(38, 20)
        Me.btnExpFirst.TabIndex = 38
        Me.btnExpFirst.Text = "|<"
        Me.btnExpFirst.UseVisualStyleBackColor = True
        '
        'btnExpPrev
        '
        Me.btnExpPrev.Location = New System.Drawing.Point(467, 339)
        Me.btnExpPrev.Name = "btnExpPrev"
        Me.btnExpPrev.Size = New System.Drawing.Size(28, 19)
        Me.btnExpPrev.TabIndex = 39
        Me.btnExpPrev.Text = "<"
        Me.btnExpPrev.UseVisualStyleBackColor = True
        '
        'btnExpNext
        '
        Me.btnExpNext.Location = New System.Drawing.Point(613, 338)
        Me.btnExpNext.Name = "btnExpNext"
        Me.btnExpNext.Size = New System.Drawing.Size(28, 23)
        Me.btnExpNext.TabIndex = 40
        Me.btnExpNext.Text = ">"
        Me.btnExpNext.UseVisualStyleBackColor = True
        '
        'btnExpLast
        '
        Me.btnExpLast.Location = New System.Drawing.Point(647, 339)
        Me.btnExpLast.Name = "btnExpLast"
        Me.btnExpLast.Size = New System.Drawing.Size(46, 20)
        Me.btnExpLast.TabIndex = 41
        Me.btnExpLast.Text = ">|"
        Me.btnExpLast.UseVisualStyleBackColor = True
        '
        'txtBoxExpPg
        '
        Me.txtBoxExpPg.Location = New System.Drawing.Point(516, 340)
        Me.txtBoxExpPg.Name = "txtBoxExpPg"
        Me.txtBoxExpPg.Size = New System.Drawing.Size(62, 20)
        Me.txtBoxExpPg.TabIndex = 42
        '
        'txtBoxQualPg
        '
        Me.txtBoxQualPg.Location = New System.Drawing.Point(520, 128)
        Me.txtBoxQualPg.Name = "txtBoxQualPg"
        Me.txtBoxQualPg.Size = New System.Drawing.Size(62, 20)
        Me.txtBoxQualPg.TabIndex = 43
        '
        'btnQualFirst
        '
        Me.btnQualFirst.Location = New System.Drawing.Point(435, 128)
        Me.btnQualFirst.Name = "btnQualFirst"
        Me.btnQualFirst.Size = New System.Drawing.Size(38, 20)
        Me.btnQualFirst.TabIndex = 44
        Me.btnQualFirst.Text = "|<"
        Me.btnQualFirst.UseVisualStyleBackColor = True
        '
        'btnQualPrev
        '
        Me.btnQualPrev.Location = New System.Drawing.Point(483, 128)
        Me.btnQualPrev.Name = "btnQualPrev"
        Me.btnQualPrev.Size = New System.Drawing.Size(28, 20)
        Me.btnQualPrev.TabIndex = 45
        Me.btnQualPrev.Text = "<"
        Me.btnQualPrev.UseVisualStyleBackColor = True
        '
        'btnQualNext
        '
        Me.btnQualNext.Location = New System.Drawing.Point(597, 128)
        Me.btnQualNext.Name = "btnQualNext"
        Me.btnQualNext.Size = New System.Drawing.Size(28, 20)
        Me.btnQualNext.TabIndex = 46
        Me.btnQualNext.Text = ">"
        Me.btnQualNext.UseVisualStyleBackColor = True
        '
        'btnQualLast
        '
        Me.btnQualLast.Location = New System.Drawing.Point(639, 128)
        Me.btnQualLast.Name = "btnQualLast"
        Me.btnQualLast.Size = New System.Drawing.Size(46, 20)
        Me.btnQualLast.TabIndex = 47
        Me.btnQualLast.Text = ">|"
        Me.btnQualLast.UseVisualStyleBackColor = True
        '
        'txtEmpPageNum
        '
        Me.txtEmpPageNum.Location = New System.Drawing.Point(115, 516)
        Me.txtEmpPageNum.Name = "txtEmpPageNum"
        Me.txtEmpPageNum.Size = New System.Drawing.Size(62, 20)
        Me.txtEmpPageNum.TabIndex = 48
        '
        'btnInfoPrev
        '
        Me.btnInfoPrev.Location = New System.Drawing.Point(68, 515)
        Me.btnInfoPrev.Name = "btnInfoPrev"
        Me.btnInfoPrev.Size = New System.Drawing.Size(28, 20)
        Me.btnInfoPrev.TabIndex = 49
        Me.btnInfoPrev.Text = "<"
        Me.btnInfoPrev.UseVisualStyleBackColor = True
        '
        'btnInfoFirst
        '
        Me.btnInfoFirst.Location = New System.Drawing.Point(24, 515)
        Me.btnInfoFirst.Name = "btnInfoFirst"
        Me.btnInfoFirst.Size = New System.Drawing.Size(38, 20)
        Me.btnInfoFirst.TabIndex = 50
        Me.btnInfoFirst.Text = "|<"
        Me.btnInfoFirst.UseVisualStyleBackColor = True
        '
        'btnInfoNext
        '
        Me.btnInfoNext.Location = New System.Drawing.Point(189, 516)
        Me.btnInfoNext.Name = "btnInfoNext"
        Me.btnInfoNext.Size = New System.Drawing.Size(28, 20)
        Me.btnInfoNext.TabIndex = 51
        Me.btnInfoNext.Text = ">"
        Me.btnInfoNext.UseVisualStyleBackColor = True
        '
        'btnInfoLast
        '
        Me.btnInfoLast.Location = New System.Drawing.Point(223, 515)
        Me.btnInfoLast.Name = "btnInfoLast"
        Me.btnInfoLast.Size = New System.Drawing.Size(46, 20)
        Me.btnInfoLast.TabIndex = 52
        Me.btnInfoLast.Text = ">|"
        Me.btnInfoLast.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(48, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 13)
        Me.Label1.TabIndex = 53
        Me.Label1.Text = "Employee Information"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(483, 10)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 13)
        Me.Label2.TabIndex = 54
        Me.Label2.Text = "Qualifications"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(469, 195)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 13)
        Me.Label3.TabIndex = 55
        Me.Label3.Text = "Work Experience"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 13)
        Me.Label4.TabIndex = 56
        Me.Label4.Text = "StaffNo"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 94)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 13)
        Me.Label5.TabIndex = 57
        Me.Label5.Text = "FName"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 120)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 13)
        Me.Label6.TabIndex = 58
        Me.Label6.Text = "LName"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 143)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(35, 13)
        Me.Label7.TabIndex = 59
        Me.Label7.Text = "Street"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 172)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(24, 13)
        Me.Label8.TabIndex = 60
        Me.Label8.Text = "City"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(3, 198)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(32, 13)
        Me.Label9.TabIndex = 61
        Me.Label9.Text = "State"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(3, 221)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(22, 13)
        Me.Label10.TabIndex = 62
        Me.Label10.Text = "Zip"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(3, 250)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(38, 13)
        Me.Label11.TabIndex = 63
        Me.Label11.Text = "Phone"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(3, 278)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(30, 13)
        Me.Label12.TabIndex = 64
        Me.Label12.Text = "DOB"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(-3, 307)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(42, 13)
        Me.Label13.TabIndex = 65
        Me.Label13.Text = "Gender"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(-3, 337)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(26, 13)
        Me.Label14.TabIndex = 66
        Me.Label14.Text = "NIN"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(-3, 363)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(44, 13)
        Me.Label15.TabIndex = 67
        Me.Label15.Text = "Position"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(-3, 386)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(52, 13)
        Me.Label16.TabIndex = 68
        Me.Label16.Text = "CurSalary"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(-3, 412)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(63, 13)
        Me.Label17.TabIndex = 69
        Me.Label17.Text = "SalaryScale"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(-3, 438)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(56, 13)
        Me.Label18.TabIndex = 70
        Me.Label18.Text = "HrsPerWk"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(-3, 464)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(76, 13)
        Me.Label19.TabIndex = 71
        Me.Label19.Text = "PosPermTemp"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(-3, 493)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(60, 13)
        Me.Label20.TabIndex = 72
        Me.Label20.Text = "TypeOfPay"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(413, 29)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(52, 13)
        Me.Label21.TabIndex = 73
        Me.Label21.Text = "QualDate"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(413, 58)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(31, 13)
        Me.Label22.TabIndex = 74
        Me.Label22.Text = "Type"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(417, 224)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(52, 13)
        Me.Label23.TabIndex = 75
        Me.Label23.Text = "OrgName"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(413, 94)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(52, 13)
        Me.Label24.TabIndex = 76
        Me.Label24.Text = "InstName"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(410, 295)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(52, 13)
        Me.Label25.TabIndex = 77
        Me.Label25.Text = "StartDate"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(421, 262)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(44, 13)
        Me.Label26.TabIndex = 78
        Me.Label26.Text = "Position"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(408, 318)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(57, 13)
        Me.Label27.TabIndex = 79
        Me.Label27.Text = "FinishDate"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(432, 457)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(29, 13)
        Me.Label28.TabIndex = 80
        Me.Label28.Text = "Field"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(428, 488)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(34, 13)
        Me.Label29.TabIndex = 81
        Me.Label29.Text = "Value"
        '
        'FormClassEmployee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(820, 617)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnInfoLast)
        Me.Controls.Add(Me.btnInfoNext)
        Me.Controls.Add(Me.btnInfoFirst)
        Me.Controls.Add(Me.btnInfoPrev)
        Me.Controls.Add(Me.txtEmpPageNum)
        Me.Controls.Add(Me.btnQualLast)
        Me.Controls.Add(Me.btnQualNext)
        Me.Controls.Add(Me.btnQualPrev)
        Me.Controls.Add(Me.btnQualFirst)
        Me.Controls.Add(Me.txtBoxQualPg)
        Me.Controls.Add(Me.txtBoxExpPg)
        Me.Controls.Add(Me.btnExpLast)
        Me.Controls.Add(Me.btnExpNext)
        Me.Controls.Add(Me.btnExpPrev)
        Me.Controls.Add(Me.btnExpFirst)
        Me.Controls.Add(Me.boxField)
        Me.Controls.Add(Me.DatePickerQual)
        Me.Controls.Add(Me.DatePickerFinishDate)
        Me.Controls.Add(Me.DatePickerStartDate)
        Me.Controls.Add(Me.DatePickerDOB)
        Me.Controls.Add(Me.txtInstName)
        Me.Controls.Add(Me.txtQualType)
        Me.Controls.Add(Me.txtOrgName)
        Me.Controls.Add(Me.txtWorkPosition)
        Me.Controls.Add(Me.boxValue)
        Me.Controls.Add(Me.txtNin)
        Me.Controls.Add(Me.txtGender)
        Me.Controls.Add(Me.txtPhone)
        Me.Controls.Add(Me.txtZip)
        Me.Controls.Add(Me.txtState)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.txtStreet)
        Me.Controls.Add(Me.txtLName)
        Me.Controls.Add(Me.txtFName)
        Me.Controls.Add(Me.txtStaffNo)
        Me.Controls.Add(Me.txtEmpPosition)
        Me.Controls.Add(Me.txtCurrSalary)
        Me.Controls.Add(Me.txtPosPermTemp)
        Me.Controls.Add(Me.txtPayType)
        Me.Controls.Add(Me.txtSalaryScale)
        Me.Controls.Add(Me.txtHrsPerWk)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAll)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.btnQualDelete)
        Me.Controls.Add(Me.btnQualSave)
        Me.Controls.Add(Me.btnQualNew)
        Me.Controls.Add(Me.btnExpDelete)
        Me.Controls.Add(Me.btnExpSave)
        Me.Controls.Add(Me.btnExpNew)
        Me.Controls.Add(Me.btnInfoDelete)
        Me.Controls.Add(Me.btnInfoSave)
        Me.Controls.Add(Me.btnInfoNew)
        Me.Name = "FormClassEmployee"
        Me.Text = "CS3630 Evan Krug Zhiwei Yang"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnInfoNew As Button
    Friend WithEvents btnInfoSave As Button
    Friend WithEvents btnInfoDelete As Button
    Friend WithEvents btnExpNew As Button
    Friend WithEvents btnExpSave As Button
    Friend WithEvents btnExpDelete As Button
    Friend WithEvents btnQualNew As Button
    Friend WithEvents btnQualSave As Button
    Friend WithEvents btnQualDelete As Button
    Friend WithEvents btnSearch As Button
    Friend WithEvents btnAll As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtHrsPerWk As TextBox
    Friend WithEvents txtSalaryScale As TextBox
    Friend WithEvents txtPayType As TextBox
    Friend WithEvents txtPosPermTemp As TextBox
    Friend WithEvents txtCurrSalary As TextBox
    Friend WithEvents txtEmpPosition As TextBox
    Friend WithEvents txtStaffNo As TextBox
    Friend WithEvents txtFName As TextBox
    Friend WithEvents txtLName As TextBox
    Friend WithEvents txtStreet As TextBox
    Friend WithEvents txtCity As TextBox
    Friend WithEvents txtState As TextBox
    Friend WithEvents txtZip As TextBox
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents txtGender As TextBox
    Friend WithEvents txtNin As TextBox
    Friend WithEvents boxValue As TextBox
    Friend WithEvents txtWorkPosition As TextBox
    Friend WithEvents txtOrgName As TextBox
    Friend WithEvents txtQualType As TextBox
    Friend WithEvents txtInstName As TextBox
    Friend WithEvents DatePickerDOB As DateTimePicker
    Friend WithEvents DatePickerStartDate As DateTimePicker
    Friend WithEvents DatePickerFinishDate As DateTimePicker
    Friend WithEvents DatePickerQual As DateTimePicker
    Friend WithEvents boxField As ComboBox
    Friend WithEvents btnExpFirst As Button
    Friend WithEvents btnExpPrev As Button
    Friend WithEvents btnExpNext As Button
    Friend WithEvents btnExpLast As Button
    Friend WithEvents txtBoxExpPg As TextBox
    Friend WithEvents txtBoxQualPg As TextBox
    Friend WithEvents btnQualFirst As Button
    Friend WithEvents btnQualPrev As Button
    Friend WithEvents btnQualNext As Button
    Friend WithEvents btnQualLast As Button
    Friend WithEvents txtEmpPageNum As TextBox
    Friend WithEvents btnInfoPrev As Button
    Friend WithEvents btnInfoFirst As Button
    Friend WithEvents btnInfoNext As Button
    Friend WithEvents btnInfoLast As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
End Class
